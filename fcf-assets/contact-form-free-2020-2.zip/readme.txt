************************************************************************
This file is part of a package from:
www.freecontactform.com

Free Version
15 September 2020

You are free to use an edit for 
your own use. But cannot resell
or repackage in any way.
****************************************************************************


Thank you for picking freecontactform.com

For details on adding this to your website, please see:

https://www.freecontactform.com/form-guides/contact-form-installation-free


Quick guide below:

    1. Open the file: fcf-assets/fcf.config.php
    2. Add your email address to the part highlighted below:
        define('EMAIL_TO', 'your email address in here');
    3. Add your email address (this email address must be known by your hosting environment) to the part highlighted below:
        define('EMAIL_FROM', 'your email address in here');
    4. Save
    5. Add the content of fcf.form.htm to your contact page.
    6. Upload ALL files (including the folder fcf-assets to your website)


More detailed installation details can be found at: 

https://www.freecontactform.com/form-guides/contact-form-installation-free



****************************************************************************

PLEASE LEAVE SOME FEEDBACK - IT ON TAKES 2 MINUTES

Thanks for downloading our free form, we'd love to hear your feedback.
This is important as it helps us to make future improvements.

https://surveys.hotjar.com/c6551a0d-b027-49f5-9bee-f9269e46f5d8

